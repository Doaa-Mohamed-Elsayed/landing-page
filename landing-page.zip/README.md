# Landing Page Project
## Project description
Responsive Landing Page project to display dynamic Navigation bar.

## Author: Doaa Mohamed Elsayed
## tech:
1. HTML5
2. CSS3
3. Javascript

## Requirements:
1. Build the dynamically navigation menu
2. Add functionality to distinguish the section in view
3. Add the functionality to scroll to sections

## API used: Intersection Observer



